export class ChargeDetail
{
name:string;
isApplicable:boolean;
chargeType:string;
id:number;
isActive:boolean;
createdBy:string;
updatedBy:string;
createdAt:Date;
updatedAt:Date;

}
