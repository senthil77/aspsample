 

export class Currency
{
currencyCode:string;
description:string;
id:number;
isActive:boolean;
createdBy:string;
updatedBy:string;
createdAt:Date;
updatedAt:Date;

}
